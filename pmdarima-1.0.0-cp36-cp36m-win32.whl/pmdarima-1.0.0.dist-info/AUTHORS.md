## Authors

The following people have been core contributors to `pyramid`'s development:

  * [Taylor Smith](https://github.com/tgsmith61591)
  * [Gary Foreman](https://github.com/garyForeman)
  * [Charles Drotar](https://github.com/charlesdrotar)
  * [Steven Hoelscher](https://github.com/shoelsch)

__Please do not email the authors directly with questions or issues.__ Rather, use
the [issues](https://github.com/tgsmith61591/pyramid/issues) page. Furthermore, issues
or emails specifically related to assistance in learning time series analysis should be
saved for Stack Overflow.
